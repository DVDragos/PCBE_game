package map;

public enum ElementType {
	PLAYER, RESOURCE, BUILDING
}
