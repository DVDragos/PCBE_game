package map;

public enum ObjectType {
	PLAYER,
	MINE,
	BUILDING
}
