package map;

import java.util.ArrayList;
import java.util.List;

public class Map {

	private List<Coordinates> mMap;
	private int mHeight;
	private int mWidth;

	public List<Coordinates> getMap() {
		return mMap;
	}

	public Map(int height, int width) {
		mMap = new ArrayList<>();
		mHeight = height;
		mWidth = width;
	}

	public synchronized void addObjectToMap(Coordinates coordinates) {
		if (!checkCoordinates(coordinates.getX(), coordinates.getY())) {
			return;
		}
		boolean isFree = true;
		for (Coordinates coord : mMap) {
			if (coord.getX() == coordinates.getX() && coord.getY() == coordinates.getY()) {
				System.out.println("There is something on the map on coordinates " + coordinates.getX() + ", "
						+ coordinates.getY());
				isFree = false;
				break;
			}
		}
		if (isFree) {
			mMap.add(coordinates);
			System.out.println(coordinates.getmObjectType().name() + " added on map at coordinates: "
					+ coordinates.getX() + ", " + coordinates.getY());
		}
	}

	public synchronized void removeObjectFromMap(Coordinates coordinates) {
		if (!checkCoordinates(coordinates.getX(), coordinates.getY())) {
			return;
		}
		for (Coordinates coord : mMap) {
			if (coord.getX() == coordinates.getX() && coord.getY() == coordinates.getY()) {
				if (coordinates.getmObjectType().name().equals(coord.getmObjectType().name())) {
					mMap.remove(coord);
				} else {
					System.out.println("Cannot delete object because the object type doesn't match.");
				}
			}
		}
	}

	private boolean checkCoordinates(int x, int y) {
		if (x < 0 || x > mHeight) {
			System.out.println("The X coordinate is outside the map.");
			return false;
		}
		if (y < 0 || y > mWidth) {
			System.out.println("The Y coordinate is outside the map.");
			return false;
		}
		return true;
	}
}
