package map;

public class Map {

}
