package map;

import player.Player;
import resource.Building;
import resource.ResourceType;

public class ElementContainer {

	private ResourceType mResource = null;
	private Player mPlayer = null;
	private Building mBuilding = null;
	private ElementType mElementType;

	public ElementContainer(ElementType elementType) {
		mElementType = elementType;
	}

	public synchronized void setPlayer(Player player) {
		if (mElementType.equals(ElementType.PLAYER) && mResource == null) {
			mPlayer = player;
		}
	}

	public synchronized void setResource(ResourceType res) {
		if (mElementType.equals(ElementType.RESOURCE) && mPlayer == null) {
			mResource = res;
		}
	}
	
	public synchronized void setBuilding(Building building) {
		if (mElementType.equals(ElementType.BUILDING) && mBuilding == null) {
			mBuilding = building;
		}
	}

	public ResourceType getResource() {
		return mResource;
	}

	public Player getPlayer() {
		return mPlayer;
	}
	
	public Building getBuilding() {
		return mBuilding;
	}

}
