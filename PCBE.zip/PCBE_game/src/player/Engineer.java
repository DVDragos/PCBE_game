package player;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import game.ThreadRunning;
import map.Coordinates;
import map.Element;
import map.ElementType;
import map.Map;
import resource.Building;
import resource.BuildingType;

public class Engineer extends ThreadRunning implements Player {

	private Map mMap;
	private Team mTeam;
	private List<MiniMap> mMiniMapEnemy;
	private List<MiniMap> mMiniMapResource;
	private List<MiniMap> mMiniMap;
	private Coordinates myCoordinates;
	private Element myElement;
	private boolean alive = true;

	/**
	 * kills the thread
	 */
	@Override
	public void die() {
		alive = false;
		mMap.releaseCoordinate(myCoordinates);
	}

	/**
	 * 
	 * @param myCoordinates the players new coordinates
	 */
	public void setMyCoordinates(Coordinates myCoordinates) {
		myElement.setNewCoordinates(myCoordinates);
//		for (Element elem : mMap.getMap()) {
//			if (elem.getCoordinates().equals(this.myCoordinates)) {
//				elem.setNewCoordinates(myCoordinates);
//			}
//		}
		this.myCoordinates = myCoordinates;
	}

	/**
	 * Constructor
	 * @param mMap the map
	 * @param mTeam players team
	 * @param coord players coordinates
	 */
	public Engineer(Map mMap, Team mTeam, Coordinates coord, Element elem) {
		this.mMap = mMap;
		this.mTeam = mTeam;
		this.myCoordinates = coord;
		this.myElement = elem;
		mMap.occupyCoordinate(coord);
	}

	/**
	 * 
	 * @return players team 
	 */
	public Team getTeam() {
		return mTeam;
	}

	public String getPlayerTeamName() {
		return mTeam.getTeamName();
	};

	@Override
	public void run() {
		while (alive && getStopSignal()) {
			// System.out.println("Thread entered");
			this.action();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		mMap.releaseCoordinate(myCoordinates);
	}

	@Override
	public void action() {
		if (alive) {
			this.makeView(mMap.get5x5MapAroundPlayer(myElement)); // create the MiniMaps of
															// the player and get
															// the coordinates
	
			// check if building is possible
			if (build() == true) {
				System.out.println(Thread.currentThread().getName() + " has finished the building");
			}
	
			else if (mMiniMapResource.isEmpty() == false) {
				double min = 999;
				Element target = null;
				for (MiniMap m : mMiniMapResource) {
					if (m.getDist() < min) {
						min = m.getDist();
						if (alive == true) {
							target = m.getElem();
						}
					}
				}
	
				if (Math.abs(target.getCoordinates().getX() - myCoordinates.getX()) == 1
						&& Math.abs(target.getCoordinates().getY() - myCoordinates.getY()) == 1) {
					if (alive == true) {
						gather(target);
					}
				}
			}
			// if none of the above then move
			move(mMap.getWidth(), mMap.getHeight());
		}

	}

	/**
	 * method that helps the player see his surrounding elements 
	 * @param playerView the 5x5 view of the player
	 */
	private void makeView(List<Element> playerView) {

		mMiniMapEnemy = new ArrayList<MiniMap>();
		mMiniMapResource = new ArrayList<MiniMap>();
		mMiniMap = new ArrayList<MiniMap>();

		// hack to find out my own coordinates
		for (Element elem : playerView) {
			if (elem.getElementType().equals(ElementType.PLAYER))
				if (elem.getElementContainer().getPlayer() != null
						&& elem.getElementContainer().getPlayer().equals(this)) {
					myCoordinates = elem.getCoordinates();
				}
		}

		for (Element elem : playerView) {
			double distance = elem.getCoordinates().getDistance(elem.getCoordinates().getX(),
					elem.getCoordinates().getY());

			if (elem.getElementType().equals("PLAYER")
					&& !elem.getElementContainer().getPlayer().getPlayerTeamName().equals(this.getPlayerTeamName())) {
				MiniMap m = new MiniMap(elem, distance);
				mMiniMapEnemy.add(m); // populate the minimap of the enemies
			} else if (elem.getElementType().equals("RESOURCE")) {
				MiniMap m = new MiniMap(elem, distance);
				mMiniMapResource.add(m); // populate the minimap of the
											// resources
			}

			MiniMap mm = new MiniMap(elem, distance);
			mMiniMap.add(mm); // populate the mMiniMap with all the elements in
								// the "view"
		}
	}

	/**
	 * 
	 * @param mTeam
	 *            the belonging players team
	 * @return a string that indicates what kind of building shall be
	 *         constructed
	 */

	private boolean build() {

		if (mTeam.constructGoldMine() == true) {
			System.out.println(Thread.currentThread().getName() + " is constructing Gold mine");
			Coordinates buildingCoord = this.myCoordinates;
			Building building = new Building(BuildingType.GOLDMINE);
			Element elem = new Element(ElementType.BUILDING, buildingCoord);
			mMap.addElementToMap(elem);
			mTeam.addBuildingToTeam(building);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		} else if (mTeam.constructQuarry() == true) {
			System.out.println(Thread.currentThread().getName() + " is constructing Quarry");
			Coordinates buildingCoord = this.myCoordinates;
			Building building = new Building(BuildingType.QUARRY);
			Element elem = new Element(ElementType.BUILDING, buildingCoord);
			mMap.addElementToMap(elem);
			mTeam.addBuildingToTeam(building);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		} else if (mTeam.constructLumberMill()) {
			System.out.println(Thread.currentThread().getName() + " is constructing Lumber mill");
			Coordinates buildingCoord = this.myCoordinates;
			Building building = new Building(BuildingType.LUMBERMILL);
			Element elem = new Element(ElementType.BUILDING, buildingCoord);
			mMap.addElementToMap(elem);
			mTeam.addBuildingToTeam(building);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		} else {
			// System.out.println("Did not build anything :(");
			return false;
		}

	}

	@Override
	public void move(int mapWidth, int mapHeight) {
		Coordinates coord = newPosition(mapWidth, mapHeight);
		while (coord == null) {
			coord = newPosition(mapWidth, mapHeight);
		}
		this.setMyCoordinates(coord);

		System.out.println(Thread.currentThread().getName() + "(team " + getPlayerTeamName() + ") has moved to " + coord.getX() + " " + coord.getY());
	}

	public Coordinates newPosition(int mapWidth, int mapHeigth) {
		Random randx = new Random();
		Random randy = new Random();
		int x, y;
		boolean flag = true;
		x = (randx.nextInt(3) - 1);
		y = (randy.nextInt(3) - 1);
		if ((myCoordinates.getX() + x) < mapWidth && (myCoordinates.getX() + x) >= 0
				&& (myCoordinates.getY() + y) < mapHeigth && (myCoordinates.getY() + y) >= 0) {
			for (MiniMap mMap : mMiniMap) {

				if (mMap.getElem().getCoordinates().getX() == (myCoordinates.getX() + x)
						&& mMap.getElem().getCoordinates().getY() == (myCoordinates.getY() + y)) {
					flag = false;
				}

			}
		} else {
			flag = false;
		}
		if (flag) {

			int index = mMap.getWidth() * (myCoordinates.getX() + x) + (myCoordinates.getY() + y);

			Coordinates newCoordinates = mMap.getAllCoordinates().get(index);
			if (mMap.occupyCoordinate(newCoordinates) == true) {
				index = mMap.getWidth() * (myCoordinates.getX()) + (myCoordinates.getY());
				Coordinates oldCoordinates = mMap.getAllCoordinates().get(index);

				oldCoordinates.releaseCoordinate();

				return new Coordinates(myCoordinates.getX() + x, myCoordinates.getY() + y);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	@Override
	public void gather(Element target) {

		Coordinates newCoordinates = target.getCoordinates();

		mTeam.addPoints(target.getElementContainer().getResource().resourcePoints()); // add
																						// points
		target.getElementContainer().getResource().addResourceToTeam(mTeam);

		mMap.removeElementFromMap(target);
		target.getElementContainer().getResource().removeResourceFromMap();

		int index = mMap.getWidth() * (myCoordinates.getX()) + (myCoordinates.getY());
		Coordinates oldCoordinates = mMap.getAllCoordinates().get(index);
		setMyCoordinates(newCoordinates);
		oldCoordinates.releaseCoordinate();

		System.out.println(Thread.currentThread().getName() + " gathered from " + newCoordinates.getX() + " " + newCoordinates.getY());

	}

}