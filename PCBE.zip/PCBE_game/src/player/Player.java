package player;

import map.*;

public interface Player extends Runnable{

	/**
	 * 
	 * @param playerView
	 *            the 3x3 view of a player
	 * @param myCoordinate
	 *            the coordinates of the player
	 * @return String that tells which is the next method to be executed
	 */

	public void action();

	/**
	 * 
	 * @param playerView
	 *            the 3x3 view of a player
	 * @param myCoordinate
	 *            the coordinates of the player
	 * @return the coordinate of the next position of the player
	 */
	public void move( int mapWidth, int mapHeigth);

	/**
	 * @param playerView
	 *            the 5x5 view of a player
	 * @param myCoordinate
	 *            the coordinates of the player
	 * @return the Element that will be deleted upon gather
	 */
	public void gather(Element elem);

	public String getPlayerTeamName();
	
	/**
	 * Kills the player
	 */
	public void die();
	
	public Team getTeam();
}
