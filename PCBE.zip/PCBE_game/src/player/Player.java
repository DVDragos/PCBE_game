package player;

public interface Player {

	public void addVictoryPoints(int victoryPoints);
	public void action();
}
