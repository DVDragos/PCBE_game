package player;

public interface Player {

}
