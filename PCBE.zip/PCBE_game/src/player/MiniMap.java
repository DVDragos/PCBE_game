package player;

import map.*;

class MiniMap {

	private Element mElem;
	private double distance;

	public MiniMap(Element mElem, double dist) {
		this.mElem = mElem;
		this.distance = dist;
	}

	public Element getElem() {
		return mElem;
	}

	public void setElem(Element mElem) {
		this.mElem = mElem;
	}

	public double getDist() {
		return distance;
	}

	public void setDist(double dist) {
		this.distance = dist;
	}
}
