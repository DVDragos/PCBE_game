package player;

import java.util.ArrayList;
import java.util.Random;

import game.ThreadRunning;

import java.util.List;

import map.Coordinates;
import map.Element;
import map.ElementType;
import map.Map;

public class Soldier extends ThreadRunning implements Player {

	private List<MiniMap> mMiniMapEnemy;
	private List<MiniMap> mMiniMapResource;
	private List<MiniMap> mMiniMap;
	private Coordinates myCoordinates;
	private Team mTeam;
	private Map mMap;
	private Element myElement;
	private boolean alive = true;

	/**
	 * kills the thread
	 */
	@Override
	public void die() {
		alive = false;
		mMap.releaseCoordinate(myCoordinates);
	}

	/**
	 * Constructor
	 * 
	 * @param mMap
	 *            the map
	 * @param mTeam
	 *            players team
	 * @param coord
	 *            players coordinates
	 */
	public Soldier(Map mMap, Team mTeam, Coordinates coord, Element elem) {
		this.mMap = mMap;
		this.mTeam = mTeam;
		this.myCoordinates = coord;
		this.myElement = elem;
		mMap.occupyCoordinate(coord);
	}

	/**
	 * 
	 * @param myCoordinates
	 *            the players new coordinates
	 */
	public void setMyCoordinates(Coordinates myCoordinates) {
		myElement.setNewCoordinates(myCoordinates);
		// for (Element elem : mMap.getMap()) {
		// if (elem.getCoordinates().equals(this.myCoordinates)) {
		// elem.setNewCoordinates(myCoordinates);
		// }
		// }
		this.myCoordinates = myCoordinates;
	}

	/**
	 * 
	 * @return players team
	 */
	public Team getTeam() {
		return mTeam;
	}

	@Override
	/**
	 * method that returns a string with the name of the belonging team
	 */
	public String getPlayerTeamName() {
		return mTeam.getTeamName();
	}

	@Override
	public void run() {
		while (alive && getStopSignal()) {
			// System.out.println("Thread entered");
			this.action();
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		mMap.releaseCoordinate(myCoordinates);
	}

	/**
	 * method that helps the player see his surrounding elements
	 * 
	 * @param playerView
	 *            the 2x2 view of the player
	 */
	private void makeView(List<Element> playerView) {
		mMiniMapEnemy = new ArrayList<MiniMap>(); // a mini map composed of only
													// the enemys in sight
		mMiniMapResource = new ArrayList<MiniMap>(); // a minimap composed of
														// only resources in
														// sight
		mMiniMap = new ArrayList<MiniMap>(); // the minimap of the player
												// composed of all elements

		// hack to find out my own coordinates
		for (Element elem : playerView) {
			if (elem.getElementType().equals(ElementType.PLAYER))
				if (elem.getElementContainer().getPlayer() != null
						&& elem.getElementContainer().getPlayer().equals(this)) {
					myCoordinates = elem.getCoordinates();
				}
		}

		for (Element elem : playerView) {
			double distance = elem.getCoordinates().getDistance(elem.getCoordinates().getX(),
					elem.getCoordinates().getY());
			if (elem.getElementType().equals("PLAYER")
					&& !elem.getElementContainer().getPlayer().getPlayerTeamName().equals(this.getPlayerTeamName())) {
				// populate the minimap in which you see the enemyes
				MiniMap m = new MiniMap(elem, distance);
				mMiniMapEnemy.add(m);
			} else if (elem.getElementType().equals("RESOURCE")) {
				// populate the minimap in which you see the resources
				MiniMap m = new MiniMap(elem, distance);
				mMiniMapResource.add(m);
			}
			// we add every element in mMiniMap
			MiniMap mm = new MiniMap(elem, distance);
			mMiniMap.add(mm);
		}
	}

	@Override
	/**
	 * chooses what action to do next
	 */
	public void action() {
		if (alive) {
			this.makeView(mMap.get5x5MapAroundPlayer(myElement)); // the player
																	// creates
																	// the new
																	// "view"
			if (mMiniMapEnemy.isEmpty() == false) { // if you have an enemy in
													// sight
				// you shoot him
				double min = 999;
				Element killTarget = null;
				for (MiniMap m : mMiniMapEnemy) {
					if (m.getDist() < min) {
						min = m.getDist();
						killTarget = m.getElem();
					}
				}
				if (alive == true) {
					kill(killTarget);
				}

			} else if (mMiniMapResource.isEmpty() == false) {
				double min = 999;
				Element target = null;
				for (MiniMap m : mMiniMapResource) {
					if (m.getDist() < min) {
						min = m.getDist();
						target = m.getElem();
					}
				}

				if (Math.abs(target.getCoordinates().getX() - myCoordinates.getX()) == 1
						&& Math.abs(target.getCoordinates().getY() - myCoordinates.getY()) == 1) {
					if (alive == true) {
						gather(target);
					}
				}
			}

			// if none of the above the player moves
			move(mMap.getWidth(), mMap.getHeight());
		}
	}

	/**
	 * 
	 * @return a Element object with the player that will be killed
	 */
	public void kill(Element target) {

		if(target.getElementContainer().getPlayer().getTeam().getTeamMembers().contains(target.getElementContainer().getPlayer())){
			target.getElementContainer().getPlayer().getTeam().getTeamMembers().remove(target.getElementContainer().getPlayer());
		}
		mMap.removeElementFromMap(target);
		mMap.releaseCoordinate(target.getCoordinates());
		mTeam.addPoints(20);
		target.getElementContainer().getPlayer().die();
		System.out.println(target.getElementContainer().getPlayer().getClass().getSimpleName() + " of team "
				+ target.getElementContainer().getPlayer().getPlayerTeamName() + " has been killed -> "
				+ target.getElementContainer().getPlayer().getClass().getSimpleName());
		if(target.getElementContainer().getPlayer().getTeam().getTeamMembers().size() == 0){
			ThreadRunning.stopAllThread();
		}
	}

	/**
	 * method to gather a target resource
	 */
	public void gather(Element target) {

		Coordinates newCoordinates = target.getCoordinates();

		mTeam.addPoints(target.getElementContainer().getResource().resourcePoints()); // add
																						// points
		target.getElementContainer().getResource().addResourceToTeam(mTeam);

		mMap.removeElementFromMap(target);
		target.getElementContainer().getResource().removeResourceFromMap();

		int index = mMap.getWidth() * (myCoordinates.getX()) + (myCoordinates.getY());
		Coordinates oldCoordinates = mMap.getAllCoordinates().get(index);
		System.out.println(Thread.currentThread().getName() + " has gathered from " + newCoordinates.getX() + " "
				+ newCoordinates.getY());
		setMyCoordinates(newCoordinates);
		oldCoordinates.releaseCoordinate();

	}

	/**
	 * move within the map edges
	 */
	@Override
	public void move(int mapWidth, int mapHeight) {
		// System.out.println("im moving");
		Coordinates coord = newPosition(mapWidth, mapHeight);
		while (coord == null) {
			// System.out.println("i cant move!!!!!!!!!!");
			coord = newPosition(mapWidth, mapHeight);
		}
		this.setMyCoordinates(coord);

		System.out.println(Thread.currentThread().getName() + "(team " + getPlayerTeamName() + ") has moved to " + coord.getX() + " " + coord.getY());
	}

	/**
	 * 
	 * @param mapWidth
	 * @param mapHeigth
	 * @return the next coordinates of the player
	 */
	public Coordinates newPosition(int mapWidth, int mapHeigth) {
		Random randx = new Random();
		Random randy = new Random();
		int x, y;
		boolean flag = true;
		x = (randx.nextInt(3) - 1);
		y = (randy.nextInt(3) - 1);
		if ((myCoordinates.getX() + x) < mapWidth && (myCoordinates.getX() + x) >= 0
				&& (myCoordinates.getY() + y) < mapHeigth && (myCoordinates.getY() + y) >= 0) {
			for (MiniMap mMap : mMiniMap) {

				if (mMap.getElem().getCoordinates().getX() == (myCoordinates.getX() + x)
						&& mMap.getElem().getCoordinates().getY() == (myCoordinates.getY() + y)) {
					flag = false;
				}

			}
		} else {
			flag = false;
		}
		if (flag) {

			int index = mMap.getWidth() * (myCoordinates.getX() + x) + (myCoordinates.getY() + y);

			Coordinates newCoordinates = mMap.getAllCoordinates().get(index);
			// if((myCoordinates.getX()+x)>1)

			// System.out.println((newCoordinates.getX())+ "
			// "+(newCoordinates.getY()));
			if (mMap.occupyCoordinate(newCoordinates) == true) {
				index = mMap.getWidth() * (myCoordinates.getX()) + (myCoordinates.getY());
				Coordinates oldCoordinates = mMap.getAllCoordinates().get(index);

				oldCoordinates.releaseCoordinate();

				return new Coordinates(myCoordinates.getX() + x, myCoordinates.getY() + y);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}
}