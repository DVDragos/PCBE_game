package player;

public class Soldier {

}
