package player;

public class Soldier implements Player {

	@Override
	public void addVictoryPoints(int victoryPoints) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void action() {
		// TODO Auto-generated method stub
		
	}

}
