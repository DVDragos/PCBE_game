package game;

import java.util.HashSet;
import java.util.Set;

import map.Coordinates;
import map.Element;
import map.ElementType;
import map.Map;
import player.Engineer;
import player.Player;
import player.Soldier;
import player.Team;
import resource.*;

public class LauncherGame {

	public static void main(String[] args) {

		Set<Thread> threadList = new HashSet<Thread>();
		Map mMap = new Map(40, 40);
		ResourceType stoneProvider = new Stone(mMap);
		threadList.add(new Thread(stoneProvider));
		ResourceType lumberProvider = new Lumber(mMap);
		threadList.add(new Thread(lumberProvider));
		ResourceType goldProvider = new Gold(mMap);
		threadList.add(new Thread(goldProvider));
		
		ElementType pl = ElementType.PLAYER;
		Team team1 = new Team("Auras");
		Team team2 = new Team("Racheta");

		Coordinates coord1 = new Coordinates(1, 1);
		Coordinates coord2 = new Coordinates(2, 1);
		Coordinates coord3 = new Coordinates(3, 1);
		
		Coordinates coord4 = new Coordinates(22, 24);
		Coordinates coord5 = new Coordinates(23, 24);
		Coordinates coord6 = new Coordinates(24, 24);

		Element elem1 = new Element(pl, coord1);
		Player player1 = new Engineer(mMap, team1, coord1, elem1);
		elem1.getElementContainer().setPlayer(player1);
		Element elem2 = new Element(pl, coord2);
		Player player2 = new Soldier(mMap, team1, coord2, elem2);
		elem2.getElementContainer().setPlayer(player2);
		Element elem3 = new Element(pl, coord3);
		Player player3 = new Soldier(mMap, team1, coord3, elem3);
		elem3.getElementContainer().setPlayer(player3);
		
		Element elem4 = new Element(pl, coord4);
		Player player4 = new Engineer(mMap, team2, coord4, elem4);
		elem4.getElementContainer().setPlayer(player4);
		Element elem5 = new Element(pl, coord5);
		Player player5 = new Soldier(mMap, team2, coord5, elem5);
		elem5.getElementContainer().setPlayer(player5);
		Element elem6 = new Element(pl, coord6);
		Player player6 = new Soldier(mMap, team2, coord6, elem6);
		elem6.getElementContainer().setPlayer(player6);
		
		Coordinates coord7 = new Coordinates(10, 14);
		Element elem7 = new Element(pl, coord7);
		Player player7 = new Engineer(mMap, team2, coord7, elem7);
		elem7.getElementContainer().setPlayer(player7);
		
		Coordinates coord8 = new Coordinates(20, 24);
		Element elem8 = new Element(pl, coord8);
		Player player8 = new Soldier(mMap, team2, coord8, elem8);
		elem8.getElementContainer().setPlayer(player8);
		
		Coordinates coord9 = new Coordinates(31, 25);
		Element elem9 = new Element(pl, coord9);
		Player player9 = new Soldier(mMap, team2, coord9, elem9);
		elem9.getElementContainer().setPlayer(player9);
		
		Coordinates coord10 = new Coordinates(27, 25);
		Element elem10 = new Element(pl, coord10);
		Player player10 = new Engineer(mMap, team1, coord10, elem10);
		elem10.getElementContainer().setPlayer(player10);
		
		Coordinates coord11 = new Coordinates(37, 25);
		Element elem11 = new Element(pl, coord11);
		Player player11 = new Soldier(mMap, team1, coord11, elem11);
		elem11.getElementContainer().setPlayer(player11);
		
		Coordinates coord12 = new Coordinates(35, 30);
		Element elem12 = new Element(pl, coord12);
		Player player12 = new Soldier(mMap, team1, coord12, elem12);
		elem12.getElementContainer().setPlayer(player12);
		
		Coordinates coord13 = new Coordinates(37, 35);
		Element elem13 = new Element(pl, coord13);
		Player player13 = new Engineer(mMap, team1, coord13, elem13);
		elem13.getElementContainer().setPlayer(player13);

		mMap.addElementToMap(elem1);
		mMap.addElementToMap(elem2);
		mMap.addElementToMap(elem3);
		mMap.addElementToMap(elem4);
		mMap.addElementToMap(elem5);
		mMap.addElementToMap(elem6);
		
		mMap.addElementToMap(elem7);
		mMap.addElementToMap(elem8);
		mMap.addElementToMap(elem9);
		mMap.addElementToMap(elem10);
		mMap.addElementToMap(elem11);
		mMap.addElementToMap(elem12);
		mMap.addElementToMap(elem13);
		
		team1.addPlayerToTeam(player1);
		team1.addPlayerToTeam(player2);
		team1.addPlayerToTeam(player3);
		
		team2.addPlayerToTeam(player4);
		team2.addPlayerToTeam(player5);
		
		
		team2.addPlayerToTeam(player6);
		team2.addPlayerToTeam(player7);
		team2.addPlayerToTeam(player8);
		team2.addPlayerToTeam(player9);
		team1.addPlayerToTeam(player10);
		team1.addPlayerToTeam(player11);
		team1.addPlayerToTeam(player12);
		team1.addPlayerToTeam(player13);
		
		team1.addGoldToStorage(100);
		team1.addStoneToStorage(100);
		
		team2.addStoneToStorage(100);
		team2.addWoodToStorage(100);
		
		new Thread(player1).start();
		new Thread(player2).start();
		new Thread(player3).start();
		new Thread(player4).start();
		new Thread(player5).start();
		new Thread(player6).start();
		
		
		new Thread(player7).start();
		new Thread(player8).start();
		new Thread(player9).start();
		new Thread(player10).start();
		new Thread(player11).start();
		new Thread(player12).start();
		new Thread(player13).start();
		
		for (Thread t : threadList) {
			t.start();
		}

		int numberOfRepeats = 24;
		try {
//			Thread.sleep(300000); // Milliseconds for 5 minutes
			while(numberOfRepeats > 0 && ThreadRunning.stopSignal){
				Thread.sleep(5000);
				numberOfRepeats--;
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ThreadRunning.stopAllThread();

		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(numberOfRepeats > 0){
			if(team1.getTeamMembers().size() < 0){
				System.out.println("Team " + team1.getTeamName() + " won by defeating all other players!");
			} else {
				System.out.println("Team " + team2.getTeamName() + " won by defeating all other players!");
			}
		} else {
			if(team1.getPoints() > team2.getPoints()){
				System.out.println("Team " + team1.getTeamName() + " won with " + team1.getPoints() + " points!");
			} else {
				System.out.println("Team " + team2.getTeamName() + " won with " + team2.getPoints() + " points!");
			}
		}
		
		System.out.println("Game over!");
	}
}
