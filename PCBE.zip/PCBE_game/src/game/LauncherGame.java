package game;

import map.Coordinates;
import map.Map;
import map.ObjectType;

public class LauncherGame {

	public static void main(String[] args) {

		Map map = new Map(5, 5);

		/* Team 1 */
		map.addObjectToMap(new Coordinates(1, 1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(2, 1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(1, 1, ObjectType.PLAYER));

		/* Wrong coordinates */
		map.addObjectToMap(new Coordinates(-1, 1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(6, 1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(1, -1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(1, 6, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(-1, -1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(6, 6, ObjectType.PLAYER));

		/* Team 2 */
		map.addObjectToMap(new Coordinates(5, 1, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(5, 2, ObjectType.PLAYER));
		map.addObjectToMap(new Coordinates(1, 1, ObjectType.PLAYER));

//		Team team1 = new Team("Racheta");
//		Team team2 = new Team("Nimanui");
		
		System.out.println("Game over!");
	}

}
