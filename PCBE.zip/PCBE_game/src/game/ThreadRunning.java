package game;

public class ThreadRunning {

	protected static boolean stopSignal;

	public ThreadRunning() {
		stopSignal = true;
	}

	public boolean getStopSignal() {
		return stopSignal;
	}

	/**
	 * Method used to stop all threads from running and to end the game
	 */
	public static void stopAllThread() {
		stopSignal = false;
	}
}
