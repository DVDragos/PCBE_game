package resource;

import player.Player;

public class Lumberjack implements ResourceType {

	@Override
	public void gatherResource(int quantity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void miner(Player player) {
		// TODO Auto-generated method stub
		
	}

}
