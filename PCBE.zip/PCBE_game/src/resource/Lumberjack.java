package resource;

public class Lumberjack implements ResourceType {

}
