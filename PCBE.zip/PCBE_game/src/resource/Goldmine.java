package resource;

public class Goldmine implements ResourceType {
	
}
