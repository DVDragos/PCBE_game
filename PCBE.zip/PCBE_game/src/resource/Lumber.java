package resource;

import java.util.concurrent.Semaphore;

import game.ThreadRunning;
import map.Coordinates;
import map.Element;
import map.ElementType;
import map.Map;
import player.Team;

public class Lumber extends ThreadRunning implements ResourceType, Runnable {

	private static int nrOfResourceOnMap = 0;
	private final int nrMustOnMap = 10;
	private final Semaphore semResource = new Semaphore(1);
	private final Semaphore semResourceToStorage = new Semaphore(1);
	private boolean canAddToStorage;

	private Map mMap;

	public Lumber(Map mMap) {
		this.mMap = mMap;
	}

	public Lumber() {
		canAddToStorage = true;
	}

	public int getNrOfResourceOnMap() {
		return Lumber.nrOfResourceOnMap;
	}

	public void spawnResource() {
		if (nrOfResourceOnMap < 10) {
			int x = (int) (Math.random() * mMap.getHeight());
			int y = (int) (Math.random() * mMap.getWidth());

			Coordinates randomCoordinate = new Coordinates(x, y);
			if (mMap.occupyCoordinate(mMap.getAllCoordinates().get(mMap.getWidth() * x + y))) {
				System.out.println("Lumber resource spawned on the map on: " + randomCoordinate.getX() + " "
						+ randomCoordinate.getY());
				addResourceToTheMap();
				Element e = new Element(ElementType.RESOURCE, randomCoordinate);
				e.getElementContainer().setResource(new Lumber());
				mMap.getMap().add(e);
//				System.out.println(nrOfResourceOnMap + " Lumbers");
			}
		}
//		if (nrOfResourceOnMap == 10)
//			System.out.println("There are enough lumber resources on the map!");
	}

	@Override
	public int getNrMustOnMap() {
		return this.nrMustOnMap;
	}

	@Override
	public void addResourceToTheMap() {
		try {
			semResource.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Lumber.nrOfResourceOnMap++;
		semResource.release();
	}

	@Override
	public void removeResourceFromMap() {
		if (nrOfResourceOnMap > 0) {
			try {
				semResource.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Lumber.nrOfResourceOnMap--;
			semResource.release();
		}

	}

	@Override
	public int resourcePoints() {
		return 30;
	}

	@Override
	public void run() {
		while (getStopSignal()) {
			spawnResource();
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public void addResourceToTeam(Team team) {
		try {
			semResourceToStorage.acquire();
			if (canAddToStorage) {
				team.addWoodToStorage(10);
				canAddToStorage = false;
			}
			semResourceToStorage.release();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
