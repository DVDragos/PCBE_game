package resource;

import player.Player;

public interface ResourceType {
	
	public void gatherResource(int quantity);
	public void miner(Player player);
}
