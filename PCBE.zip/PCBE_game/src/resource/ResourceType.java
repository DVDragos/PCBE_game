package resource;

public interface ResourceType {

}
