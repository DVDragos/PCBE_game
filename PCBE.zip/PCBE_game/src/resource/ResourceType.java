package resource;

import player.Team;

public interface ResourceType extends Runnable {

	/**
	 * @return The total number of the resource type on the map
	 * 
	 */
	public int getNrOfResourceOnMap();

	/**
	 * @return The total number of the resource type that MUST be on the map
	 * 
	 */
	public int getNrMustOnMap();

	/**
	 * After The Resource was created and it's coordinates where validated for
	 * populating the map the number of the resource type on the map increases
	 */
	public void addResourceToTheMap();

	/**
	 * After The Resource was collected by one of the teams, it disappears from
	 * the map therefore the number of this recourse types needs to be
	 * decremented
	 */
	public void removeResourceFromMap();
	
	/**
	 * 
	 * @return the number of points that the resource has
	 */
	public int resourcePoints();
	
	public void addResourceToTeam(Team team);
}