package resource;

public enum BuildingType {
	LUMBERMILL, QUARRY, GOLDMINE
}
