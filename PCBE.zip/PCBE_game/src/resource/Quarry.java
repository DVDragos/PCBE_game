package resource;

public class Quarry implements ResourceType {

}
