package resource;

import java.util.concurrent.Semaphore;

public class Stone implements ResourceType{

	private static int nrOfResourceOnMap = 0;
	private final int nrMustOnMap = 10;
	private final Semaphore semResource = new Semaphore(1);

	@Override
	public int getNrOfResourceOnMap() {
		return Stone.nrOfResourceOnMap;
	}

	@Override
	public int getNrMustOnMap() {
		return this.nrMustOnMap;
	}

	@Override
	public void addResourceToTheMap() {
		if (nrOfResourceOnMap < 10) {
			try {
				semResource.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stone.nrOfResourceOnMap++;
			semResource.release();
		}
	}

	@Override
	public void removeResourceFromMap() {
		if (nrOfResourceOnMap > 0) {
			try {
				semResource.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Stone.nrOfResourceOnMap--;
			semResource.release();
		}

	}

	@Override
	public int resourcePoints() {
		return 10;
	}
}
