package resource;

import java.util.concurrent.Semaphore;

public class Lumber implements ResourceType {

	private static int nrOfResourceOnMap = 0;
	private final int nrMustOnMap = 10;
	private final Semaphore semResource = new Semaphore(1);

	public int getNrOfResourceOnMap() {
		return Lumber.nrOfResourceOnMap;
	}

	@Override
	public int getNrMustOnMap() {
		return this.nrMustOnMap;
	}

	@Override
	public void addResourceToTheMap() {
		if (nrOfResourceOnMap < 10) {
			try {
				semResource.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Lumber.nrOfResourceOnMap++;
			semResource.release();
		}
	}

	@Override
	public void removeResourceFromMap() {
		if (nrOfResourceOnMap > 0) {
			try {
				semResource.acquire();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Lumber.nrOfResourceOnMap--;
			semResource.release();
		}

	}

	@Override
	public int resourcePoints() {
		return 30;
	}

}
