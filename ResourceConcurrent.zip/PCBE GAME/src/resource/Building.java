package resource;

public class Building{

	private BuildingType mBuildingType = null;
	
	public BuildingType getBuildingType() {
		return mBuildingType;
	}

	public Building(BuildingType buildingType){
		mBuildingType = buildingType;
	}
	
	/**
	 * Method that returns the new resource quantity.
	 * @param resource original amount of resource.
	 * @return the new amount of resource.
	 */
	public int addResourceFromBuilding(int resource){
		return resource++;
	}
	
}
